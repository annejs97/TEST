package com.example.cart_finish.views;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.cart_finish.R;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivityReview extends AppCompatActivity {

        private FirebaseUser firebaseUser;
        private TextView textName;
        GoogleSignInOptions gso;
        GoogleSignInClient gsc;
        BottomNavigationView bottomNavigationView;

        @SuppressLint({"SetTextI18n", "MissingInflatedId"})
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main_review);

            textName = findViewById(R.id.usernamereview);
            bottomNavigationView = findViewById(R.id.navigation_bottom);

            bottomNavigationView.setSelectedItemId(R.id.reviewmenu);
            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    switch (item.getItemId())
                    {
                        case R.id.cartmenu:
                            startActivity(new Intent(getApplicationContext(), CartActivity.class));
                            overridePendingTransition(0,0);
                            return true;

                        case R.id.reviewmenu:

                            return true;

                        case R.id.scannermenu:
                            startActivity(new Intent(getApplicationContext(),MainActivitySplashScreen.class));
                            overridePendingTransition(0,0);
                            return true;

                        case R.id.profilemenu:
                            startActivity(new Intent(getApplicationContext(),MainActivityProfile.class));
                            overridePendingTransition(0,0);
                            return true;
                    }

                    return false;
                }
            });

            firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

            gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
            gsc = GoogleSignIn.getClient(this,gso);

            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
            if (account!=null){
                String personName = account.getDisplayName();
                textName.setText(personName);
            }else{
                textName.setText("Login Gagal");
            }


            if(firebaseUser!=null){
                textName.setText(firebaseUser.getDisplayName());
            }else{
                textName.setText("Login Gagal");
            }

        }
    }